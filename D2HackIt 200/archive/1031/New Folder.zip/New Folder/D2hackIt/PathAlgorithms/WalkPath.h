/////////////////////////////////////////////////////////////////////////
//
//  WalkPath.h
//
//  Labyrinth Pathing Algorithm by Ustc_tweeg 
//
//  Ustc_tweeg < ustc_tweeg@tom.com >
//
/////////////////////////////////////////////////////////////////////////

#ifndef __WALKPATH_H__
#define __WALKPATH_H__

#define __IN_DIABLOII__ // Comment this line out if not used in game

#include <Windows.h>

#ifndef __IN_DIABLOII__
	#include <stdio.h>
	#include "ArrayEx.h"
#else
	#include "D2Hackit.h"
	#include "..\\Utilities\\ArrayEx.h"
#endif

class CWalkPath  
{
public:	

	CWalkPath(WORD** Map, int MapSizeX, int MapSizeY);
	virtual ~CWalkPath();

	// return number of path points found, including the start and the end point
	// return 0 if pathing fail
	int FindWalkPath (POINT Start, POINT End, LPPOINT Path, DWORD dwMaxCount);

private:

	WORD** m_Map;
	int m_MapSizeX, m_MapSizeY;

	POINT m_Start,m_End,m_Meet,m_Seperate;
	POINT m_LCurrent,m_RCurrent,m_LastLineDot;

	CArrayEx<POINT, const POINT> ContinuousPath;
	POINT* LeftWallPath;
	POINT* RightWallPath;
	int m_LeftWallCount,m_RightWallCount,m_Count;

	int m_LStart,m_RStart; 

	BOOL m_Direct,m_FollowWallSuccess;

	BOOL IsBorder(POINT pt);
	BOOL IsBarrier(POINT pt);
	BOOL IsDirect(POINT pt1, POINT pt2);
	long GetDistance(long x1, long y1, long x2, long y2);
	void FollowTheRope(POINT Dot);
	BOOL FollowTheWall(BOOL RightWall, POINT FollowEnd);
	void SaveFollowWallPath();
	void StraightenThePath(LPPOINT Path, DWORD dwMaxCount);
	DWORD FurtherStraighten(LPPOINT lpPath, DWORD dwMaxCount);
	static void CALLBACK FindPathProc(int X, int Y, LPARAM lpData); 
	static void CALLBACK IsDirectProc(int x, int y, LPARAM lpData);
};



#endif // __WALKPATH_H__
